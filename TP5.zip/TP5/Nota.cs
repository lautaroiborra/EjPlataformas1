﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tp_5
{
    public class Nota
    {
        public int id_nota { get; set; }
        public String tipo { get; set; }
        public DateTime fecha { get; set; }
        public int val { get; set; }
        public int id_mat { get; set; }

        public Nota(int id_not, string tipo, DateTime fecha, int valor, int id_mate)
        {
            this.id_nota = id_not;
            this.tipo = tipo;
            this.fecha = fecha;
            this.val = valor;
            this.id_mat = id_mate;
        }

        public string ToString()
        {
            return string.Format("ID: {0}, Tipo: {1}, Fecha: {2:d} Valor: {3} MateriaID:{4}", id_nota, tipo, fecha, val, id_mat);
        }
    }
}
