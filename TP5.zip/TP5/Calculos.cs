﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tp_5
{
    public static class Promedio
    {

        public static double calcularPromedio(int [] val)
        {
            double total = 0;
            for(int i =0; i<=val.Length; i++)
            {
                total += val[i];
            }
            total = total / val.Length;
            return total;
        }

    }
}
