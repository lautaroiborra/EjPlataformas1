﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP5
{
    class Nota
    { 
        public DateTime Fecha { get; set; }
        public int Valor { get; set; }
        public string Tipo { get; set; }
    }
}
