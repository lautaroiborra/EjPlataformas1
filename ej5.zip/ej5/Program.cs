﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP5
{
    class Program
    {
        static void Main(string[] args)
        {

            Materia mat1 = new Materia
            {
                Año = 2019,
                Cuatrimestre = 4,
                Nombre = "Base de datos III",
                not = new List<Nota> {
                    new Nota { Fecha = DateTime.Now, Tipo = "Trabajo Practico", Valor = 7 },
                    new Nota { Fecha = DateTime.Now, Tipo = "Parcial 1", Valor = 6},
                    new Nota {Fecha = DateTime.Now, Tipo ="Parcial 2", Valor = 8 },
                    new Nota {Fecha = DateTime.Now, Tipo="Trabajo Practico", Valor = 10 },
                    new Nota {Fecha = DateTime.Now, Tipo = "Parcial 1", Valor = 6 },
                    new Nota {Fecha = DateTime.Now, Tipo = "Parcial 2", Valor = 4}
                }
            };

            Materia mat2 = new Materia
            {
                Año = 2019,
                Cuatrimestre = 4,
                Nombre = "Plataformas de Desarrollo",
                not = new List<Nota> {
                    new Nota { Fecha = DateTime.Now, Tipo = "Trabajo Practico", Valor = 5 },
                    new Nota { Fecha = DateTime.Now, Tipo = "Parcial 1", Valor = 7},
                    new Nota { Fecha = DateTime.Now, Tipo ="Parcial 2", Valor = 4 },
                    new Nota { Fecha = DateTime.Now, Tipo="Trabajo Practico", Valor = 8 },
                    new Nota { Fecha = DateTime.Now, Tipo = "Parcial 1", Valor = 10 },
                    new Nota { Fecha = DateTime.Now, Tipo = "Parcial 2", Valor = 9}
                }
            };

            Materia mat3 = new Materia
            {
                Año = 2019,
                Cuatrimestre = 4,
                Nombre = "Apps Moviles",
                not = new List<Nota> {
                    new Nota { Fecha = DateTime.Now, Tipo = "TP", Valor = 4 },
                    new Nota { Fecha = DateTime.Now, Tipo = "PARCIAL1", Valor = 3},
                    new Nota { Fecha = DateTime.Now, Tipo ="PARCIAL2", Valor = 5 },
                    new Nota { Fecha = DateTime.Now, Tipo="TP", Valor = 7 },
                    new Nota { Fecha = DateTime.Now, Tipo = "PARCIAL1", Valor = 5 },
                    new Nota { Fecha = DateTime.Now, Tipo = "PARCIAL2", Valor = 7}
                }
            };


            Materia mat4 = new Materia
            {
                Año = 2019,
                Cuatrimestre = 3,
                Nombre = "Programacion avanzada",
                not = new List<Nota> {
                    new Nota { Fecha = DateTime.Now, Tipo = "TP", Valor = 5 },
                    new Nota { Fecha = DateTime.Now, Tipo = "PARCIAL1", Valor = 4},
                    new Nota { Fecha = DateTime.Now, Tipo ="PARCIAL2", Valor = 7 },
                    new Nota { Fecha = DateTime.Now, Tipo="TP", Valor = 8 },
                    new Nota { Fecha = DateTime.Now, Tipo = "PARCIAL1", Valor = 4 },
                    new Nota { Fecha = DateTime.Now, Tipo = "PARCIAL2", Valor = 6}
                }
            };

            var materias = new List<Materia>()
            {
                mat1,
                mat2,
                mat3,
                mat4
            };

            var cuatri1 = 0;

            materias.OrderBy(n => n.Nombre).ToList();

            foreach (Materia mat in materias)
            {
                if(mat.Cuatrimestre == 1)
                { 
                    cuatri1++;
                }

                Console.WriteLine("materias: " +  mat.Nombre.ToString() + " " + mat.Año.ToString() + " "  + mat.Cuatrimestre.ToString());
                var promedio = mat.not.Average(notas => notas.Valor);
          
                Console.WriteLine("el promedio de " + mat.Nombre + " es: " + promedio);


                foreach (var not1 in mat.not)
                {
                    if(not1.Tipo == "Trabajo Practico")
                    {
                        Console.WriteLine("Notas de trabajos practicos: " + not1.Tipo.ToString() + " " + not1.Fecha.ToString() + " " + not1.Valor.ToString());
                    }                   
                }
            }

            Console.WriteLine("hay " + cuatri1 + " materias del cuarto cuatrimestre");
            Console.ReadLine();
    }
    }
}
