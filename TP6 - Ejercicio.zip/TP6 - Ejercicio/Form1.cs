﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TP6___Ejercicio
{
    public partial class Registro : Form
    {
        List<string> notas = new List<string>();
        List<string> alumnos = new List<string>();
        
        public Registro()
        {
            InitializeComponent();
            fillComboBox();
        }

        private void fillComboBox()
        {
            List<Materia> listaMaterias = new List<Materia>()
            {
                new Materia { Nombre = "Plataformas de Desarrollo"},
                new Materia { Nombre = "Apps Moviles"},
                new Materia { Nombre = "Analisis y Metodología de Sistemas"},
                new Materia { Nombre = "Comunicaciones y Redes" }
                
            };

            comboMateria.DataSource = listaMaterias;

        }


        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void botonGuardar_Click(object sender, EventArgs e)
        {
            string nombre;
            string apellido;
            string dni;
            string fecha;
            string nota;
            string materia;

            
            nombre = txt_nombre.Text;
            apellido = txt_apellido.Text;
            dni = txt_legajo.Text;
            fecha = txt_fecha.Text;
            nota = txt_nota.Text;
            materia = comboMateria.Text;

            Lista_de_alumnos.DataSource = null;
            Lista_de_alumnos.DataSource = notas;

            alumnos.Add(nombre);
            alumnos.Add(apellido);
            alumnos.Add(dni);
            alumnos.Add(materia);
            alumnos.Add(fecha);
            alumnos.Add(nota);
            notas.Add(materia);

            notas.Add(fecha);
            notas.Add(nota);

            comboMateria.Refresh();
            txt_fecha.Clear();
            txt_nota.Clear();

            Lista_de_notas.DataSource = null;
            Lista_de_notas.DataSource = alumnos;

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {  }

        private void limpiarNotas_Click(object sender, EventArgs e)
        {
            Lista_de_alumnos.DataSource = null;
        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void listAlumnos_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }
    }
}
