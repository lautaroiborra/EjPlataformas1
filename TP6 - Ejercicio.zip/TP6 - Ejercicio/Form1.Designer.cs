﻿namespace TP6___Ejercicio
{
    partial class Registro
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registro));
            this.Lista_de_alumnos = new System.Windows.Forms.ListBox();
            this.comboMateria = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.txt_apellido = new System.Windows.Forms.TextBox();
            this.txt_legajo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txt_fecha = new System.Windows.Forms.TextBox();
            this.txt_nota = new System.Windows.Forms.TextBox();
            this.botonGuardar = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.Lista_de_notas = new System.Windows.Forms.ListBox();
            this.limpiarNotas = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Lista_de_alumnos
            // 
            this.Lista_de_alumnos.AccessibleName = "";
            this.Lista_de_alumnos.BackColor = System.Drawing.SystemColors.Window;
            this.Lista_de_alumnos.FormattingEnabled = true;
            this.Lista_de_alumnos.ItemHeight = 14;
            this.Lista_de_alumnos.Location = new System.Drawing.Point(344, 13);
            this.Lista_de_alumnos.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Lista_de_alumnos.Name = "Lista_de_alumnos";
            this.Lista_de_alumnos.Size = new System.Drawing.Size(277, 116);
            this.Lista_de_alumnos.TabIndex = 0;
            this.Lista_de_alumnos.SelectedIndexChanged += new System.EventHandler(this.listAlumnos_SelectedIndexChanged);
            // 
            // comboMateria
            // 
            this.comboMateria.FormattingEnabled = true;
            this.comboMateria.Location = new System.Drawing.Point(77, 112);
            this.comboMateria.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.comboMateria.Name = "comboMateria";
            this.comboMateria.Size = new System.Drawing.Size(175, 22);
            this.comboMateria.TabIndex = 1;
            this.comboMateria.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 112);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 14);
            this.label1.TabIndex = 2;
            this.label1.Text = "Materia";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 45);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 14);
            this.label3.TabIndex = 4;
            this.label3.Text = "Apellido";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 79);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 14);
            this.label4.TabIndex = 5;
            this.label4.Text = "Legajo";
            // 
            // txt_nombre
            // 
            this.txt_nombre.Location = new System.Drawing.Point(87, 13);
            this.txt_nombre.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(132, 21);
            this.txt_nombre.TabIndex = 6;
            // 
            // txt_apellido
            // 
            this.txt_apellido.Location = new System.Drawing.Point(87, 45);
            this.txt_apellido.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_apellido.Name = "txt_apellido";
            this.txt_apellido.Size = new System.Drawing.Size(132, 21);
            this.txt_apellido.TabIndex = 7;
            // 
            // txt_legajo
            // 
            this.txt_legajo.Location = new System.Drawing.Point(87, 79);
            this.txt_legajo.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_legajo.Name = "txt_legajo";
            this.txt_legajo.Size = new System.Drawing.Size(132, 21);
            this.txt_legajo.TabIndex = 8;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 16);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 14);
            this.label2.TabIndex = 9;
            this.label2.Text = "Nombre";
            this.label2.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 145);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 14);
            this.label5.TabIndex = 10;
            this.label5.Text = "Fecha";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 196);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 14);
            this.label6.TabIndex = 11;
            this.label6.Text = "Nota";
            // 
            // txt_fecha
            // 
            this.txt_fecha.Location = new System.Drawing.Point(77, 145);
            this.txt_fecha.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_fecha.Name = "txt_fecha";
            this.txt_fecha.Size = new System.Drawing.Size(137, 21);
            this.txt_fecha.TabIndex = 12;
            // 
            // txt_nota
            // 
            this.txt_nota.Location = new System.Drawing.Point(77, 193);
            this.txt_nota.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.txt_nota.Name = "txt_nota";
            this.txt_nota.Size = new System.Drawing.Size(136, 21);
            this.txt_nota.TabIndex = 13;
            // 
            // botonGuardar
            // 
            this.botonGuardar.Location = new System.Drawing.Point(43, 254);
            this.botonGuardar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.botonGuardar.Name = "botonGuardar";
            this.botonGuardar.Size = new System.Drawing.Size(100, 25);
            this.botonGuardar.TabIndex = 14;
            this.botonGuardar.Text = "Guardar";
            this.botonGuardar.UseVisualStyleBackColor = true;
            this.botonGuardar.Click += new System.EventHandler(this.botonGuardar_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(224, 149);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 14);
            this.label7.TabIndex = 15;
            this.label7.Text = "(YYYY)";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // Lista_de_notas
            // 
            this.Lista_de_notas.FormattingEnabled = true;
            this.Lista_de_notas.ItemHeight = 14;
            this.Lista_de_notas.Location = new System.Drawing.Point(344, 149);
            this.Lista_de_notas.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Lista_de_notas.Name = "Lista_de_notas";
            this.Lista_de_notas.Size = new System.Drawing.Size(277, 116);
            this.Lista_de_notas.TabIndex = 16;
            // 
            // limpiarNotas
            // 
            this.limpiarNotas.Location = new System.Drawing.Point(183, 254);
            this.limpiarNotas.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.limpiarNotas.Name = "limpiarNotas";
            this.limpiarNotas.Size = new System.Drawing.Size(100, 25);
            this.limpiarNotas.TabIndex = 17;
            this.limpiarNotas.Text = "Borrar";
            this.limpiarNotas.UseVisualStyleBackColor = true;
            this.limpiarNotas.Click += new System.EventHandler(this.limpiarNotas_Click);
            // 
            // Registro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(656, 319);
            this.Controls.Add(this.limpiarNotas);
            this.Controls.Add(this.Lista_de_notas);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.botonGuardar);
            this.Controls.Add(this.txt_nota);
            this.Controls.Add(this.txt_fecha);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_legajo);
            this.Controls.Add(this.txt_apellido);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboMateria);
            this.Controls.Add(this.Lista_de_alumnos);
            this.Font = new System.Drawing.Font("Montserrat Subrayada", 8.249999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Registro";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox Lista_de_alumnos;
        private System.Windows.Forms.ComboBox comboMateria;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.TextBox txt_apellido;
        private System.Windows.Forms.TextBox txt_legajo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txt_fecha;
        private System.Windows.Forms.TextBox txt_nota;
        private System.Windows.Forms.Button botonGuardar;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ListBox Lista_de_notas;
        private System.Windows.Forms.Button limpiarNotas;
    }
}

