﻿using System;

namespace Ejercicio2
{
    internal class Caja_de_cambios : Caja_de_cambiosI
    {
        private int cantCambios;
        private bool eltipo = false;

        public Caja_de_cambios(int cant)
        {
            cantCambios = cant;
        }

        public int cantidadCambios
        {
            get
            {
                return cantCambios;
            }

            set
            {
                Console.WriteLine("Ingresar nueva cantidad:");
                int cant1 = int.Parse(Console.ReadLine());
                this.cantCambios = cant1;
            }
        }

        public bool tipo
        {
            get
            {
                return eltipo;
            }

            set
            {
                eltipo = value;
            }
        }

        public void tipoAutomatico()
        {
            bool tipoAut = true;
            if(eltipo == true)
            {
                Console.WriteLine("ERROR: Tipo de cambio 'Automatico' ya activo");
                Console.ReadLine();
            }
            else
            {
                eltipo = tipoAut;
                Console.WriteLine("Tipo de cambio 'Automatico' activado");
                Console.ReadKey();
            }
        
        }
        public void tipoManual()
        {
            bool tipoAut = false;
            if(eltipo == false)
            {
                Console.WriteLine("ERROR: Tipo de cambio 'Manual' ya activo");
                Console.ReadLine();
            }else
            {
                eltipo = tipoAut;
                Console.WriteLine("Tipo de cambio 'Manual' activado");
                Console.ReadKey();
            }
            
        }
    }
}