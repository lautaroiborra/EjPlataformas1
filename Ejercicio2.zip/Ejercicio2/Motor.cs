﻿using System;

namespace Ejercicio2
{
    internal class Motor : MotorI
    {
        public double cilindrada { get; set; }

        public Motor(double cil)
        {
            cilindrada = cil;
        }

        public void iniciar()
        {
            Console.WriteLine("Motor iniciado");
        }
        public void frenar()
        {
            Console.WriteLine("Motor frenado");
        }
    }
}