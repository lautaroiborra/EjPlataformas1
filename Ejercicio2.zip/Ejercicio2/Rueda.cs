﻿using System;

namespace Ejercicio2
{
    internal class Rueda : RuedaI
    {
        public double diametro { get; set; }

        public Rueda(double dia)
        {
            diametro = dia;
        }

        public void iniciar()
        {
            Console.WriteLine("Ruedas iniciadas");
        }

        public void frenar()
        {
            Console.WriteLine("Ruedas frenadas");
        }
    }
}