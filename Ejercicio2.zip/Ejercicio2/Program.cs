﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2
{
    class Program
    {
        static void Main(string[] args)
        {
            Autopartes auto1 = new Autopartes(new List<Rueda> {new Rueda(10.5), new Rueda(15.3), new Rueda(12.4), new Rueda(21.1) }, new Motor(15.5), new Caja_de_cambios(3));
            auto1.verificarRuedas();
            Autopartes auto2 = new Autopartes(new List<Rueda> { new Rueda(8.5), new Rueda(10.3), new Rueda(16.4), new Rueda(21.7) }, new Motor(5.8), new Caja_de_cambios(4));
            auto2.verificarRuedas();
            Autopartes auto3 = new Autopartes(new List<Rueda> { new Rueda(10.5), new Rueda(12.3), new Rueda(12.7), new Rueda(24.1), new Rueda(17.3) }, new Motor(10.5), new Caja_de_cambios(1));
            auto3.verificarRuedas();
            Autopartes auto4 = new Autopartes(new List<Rueda> { new Rueda(19.5), new Rueda(10.3), new Rueda(11.4), new Rueda(15.1) }, new Motor(12.5), new Caja_de_cambios(2));
            auto4.verificarRuedas();
        }
    }
}
