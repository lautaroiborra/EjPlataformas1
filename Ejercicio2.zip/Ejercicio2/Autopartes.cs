﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Ejercicio2
{
    class Autopartes
    {

        List<Rueda> ruedas = new List<Rueda>();
        Motor motor { get; set; }
        Caja_de_cambios caja { get; set; }

        public Autopartes(List<Rueda> rue, Motor mot, Caja_de_cambios caj)
        {
            ruedas = rue;
            motor = mot;
            caja = caj;
        }

        public bool verificarRuedas()
        {
            if (ruedas.Capacity == 4)
            {
                Console.WriteLine("Automóvil Habilitado");
                Console.ReadLine();
                return true;
            }
            else
            {
                Console.WriteLine("Automóvil No Habilitado");
                Console.ReadLine();
                return false;
            }
        }
    }
}
