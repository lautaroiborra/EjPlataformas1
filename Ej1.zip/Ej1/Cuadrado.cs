﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Cuadrado
    {
        private double _lado1;
        public double lado1 { get { return _lado1; } set { _lado1 = value; lado2 = value;lado3 = value;lado4 = value; } }
        public double lado2
        {
            get; set;
        }
        public double lado3
        {
            get; set;
        }

        public double lado4
        {
            get; set;
        }


        public Cuadrado(double lado)
        {
            lado1 = lado;
            this.lado2 = lado;
            this.lado3 = lado;
            this.lado4 = lado;
        }
        public Cuadrado()
        {

        }

        public double getLado()
        {
            return lado1;
        }

        public double calcularArea()
        {
            double res = 0;
            res = lado1 * this.lado2;
            return res;
        }
        public double calcularPerimetro()
        {
            double res = 0;
            res = lado1 * 4;
            return res;
        }
    }
}
