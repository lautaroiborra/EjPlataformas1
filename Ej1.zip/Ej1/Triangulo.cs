﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Triangulo : Calculo
    {

    public double lado1 = Double.Parse(Console.ReadLine());
       
    public double ladobase = Double.Parse(Console.ReadLine());
  
    public double lado3 = Double.Parse(Console.ReadLine());


        public Triangulo(double lado1, double lado2, double lado3)
        {
            this.lado1 = lado1;
            this.ladobase = lado2;
            this.lado3 = lado3;
        }
        public Triangulo()
        {

        }

        public double calcularArea()
        {
            double res = 0;
            res = (this.ladobase * this.lado1) / 2;
            return res;
        }

        public double calcularPerimetro()
        {
            double res = 0;
            res = this.lado1 + this.ladobase + this.lado3;
            return res;
        }
    }
}
