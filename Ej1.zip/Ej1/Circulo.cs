﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Circulo : Calculo
    {

        public double diametro = Double.Parse(Console.ReadLine());

        public Circulo(double diametro)
        {
            this.diametro = diametro;
        }
        public Circulo()
        {

        }

        public double calcularArea()
        {
            double radio = 0;
            double res = 0;
            radio = diametro / 2;
            res = (radio * radio) * Math.PI;
            return res;
        }
        public double calcularPerimetro()
        {
            double res = 0;
            res = this.diametro * Math.PI;
            return res;
        }
    }
}
