﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingresar Diámetro del circulo:");
            Circulo cir = new Circulo();
            double per = 0;
            double ar = 0;
            ar = cir.calcularArea();
            per = cir.calcularPerimetro();
            Console.Write("El area del circulo es: " + ar);
            Console.Write(" El perímetro del circulo es: " + per);
            Console.ReadKey();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Ingrese longitud de lado del cuadrado:");
            Cuadrado cua = new Cuadrado();
            double per1 = 0;
            double ar1 = 0;
            ar1 = cua.calcularArea();
            per1 = cua.calcularPerimetro();
            Console.Write("El area del cuadrado es: " + ar1);
            Console.Write(" El perímetro del cuadrado es: " + per1);
            Console.ReadKey();
            Console.WriteLine();
            Console.WriteLine();
            Console.WriteLine("Ingrese longitud de los 3 lados del triangulo:");
            Triangulo tri = new Triangulo();
            double per2 = 0;
            double ar2 = 0;
            ar2 = tri.calcularArea();
            per2 = tri.calcularPerimetro();
            Console.Write("El area del triangulo es: " + ar2);
            Console.Write(" El perímetro del triangulo es: " + per2);
            Console.ReadKey();


        }
    }
    
}
